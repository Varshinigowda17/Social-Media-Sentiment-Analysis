"""
Project: Social Media Sentiment & Engagement Analysis — AI Trends 2026
Phase 1: Data Cleaning + Exploratory Data Analysis
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

pd.set_option("display.max_columns", None)
sns.set_style("whitegrid")

# ---------------------------------------------------------
# 1. LOAD DATA
# ---------------------------------------------------------
df = pd.read_csv("data/Social_Media_Sentiment_Analysis_AI_Trends_2026.csv")
print("Shape:", df.shape)
print("\nColumn types:\n", df.dtypes)

# ---------------------------------------------------------
# 2. INITIAL INSPECTION
# ---------------------------------------------------------
print("\nMissing values per column:\n", df.isnull().sum()[df.isnull().sum() > 0])
print("\nDuplicate rows:", df.duplicated().sum())

# ---------------------------------------------------------
# 3. CLEANING
# ---------------------------------------------------------

# 3a. Parse datetime
df["posted_datetime"] = pd.to_datetime(df["posted_datetime"], errors="coerce")

# 3b. Handle missing mentions/hashtags — these are legitimately empty for many posts,
# so fill with "none" rather than dropping rows (dropping would lose ~good data)
df["mentions"] = df["mentions"].fillna("none")
df["hashtags"] = df["hashtags"].fillna("none")

# 3c. Drop exact duplicate rows if any
before = len(df)
df = df.drop_duplicates()
print(f"\nDropped {before - len(df)} duplicate rows")

# 3d. Sanity-check score ranges (sentiment_score should be -1 to 1, toxicity 0 to 1)
print("\nsentiment_score range:", df["sentiment_score"].min(), "to", df["sentiment_score"].max())
print("toxicity_score range:", df["toxicity_score"].min(), "to", df["toxicity_score"].max())
print("engagement_score range:", df["engagement_score"].min(), "to", df["engagement_score"].max())

# ---------------------------------------------------------
# 4. FEATURE ENGINEERING
# ---------------------------------------------------------

# Hour of day posted (engagement often varies by posting time)
df["posted_hour"] = df["posted_datetime"].dt.hour

# Hashtag count (split on comma, ignore "none")
df["hashtag_count"] = df["hashtags"].apply(
    lambda x: 0 if x == "none" else len(x.split(","))
)

# Mention count
df["mention_count"] = df["mentions"].apply(
    lambda x: 0 if x == "none" else len(x.split(","))
)

# Total interactions (useful combined engagement metric)
df["total_interactions"] = df["like_count"] + df["comment_count"] + df["share_count"]

# ---------------------------------------------------------
# 5. EXPLORATORY DATA ANALYSIS
# ---------------------------------------------------------

# 5a. Sentiment distribution overall
print("\nSentiment label distribution:\n", df["sentiment_label"].value_counts())

# 5b. Sentiment by platform
sentiment_by_platform = pd.crosstab(df["platform"], df["sentiment_label"], normalize="index") * 100
print("\nSentiment % by platform:\n", sentiment_by_platform.round(1))

# 5c. Average engagement by platform
avg_engagement = df.groupby("platform")["engagement_score"].mean().sort_values(ascending=False)
print("\nAvg engagement score by platform:\n", avg_engagement.round(3))

# 5d. Average engagement by topic category
avg_by_topic = df.groupby("topic_category")["engagement_score"].mean().sort_values(ascending=False)
print("\nAvg engagement score by topic category:\n", avg_by_topic.round(3))

# 5e. Trending vs non-trending engagement
trending_comparison = df.groupby("is_trending_topic")["engagement_score"].mean()
print("\nAvg engagement — trending vs not:\n", trending_comparison.round(3))

# 5f. Toxicity/spam rates by platform
tox_spam = df.groupby("platform")[["toxicity_score", "spam_flag"]].mean()
print("\nAvg toxicity score & spam rate by platform:\n", tox_spam.round(3))

# ---------------------------------------------------------
# 6. VISUALIZATIONS (saved as PNG for README/portfolio)
# ---------------------------------------------------------

fig, axes = plt.subplots(2, 2, figsize=(14, 10))

# Sentiment distribution
df["sentiment_label"].value_counts().plot(kind="bar", ax=axes[0, 0], color="#4C72B0")
axes[0, 0].set_title("Sentiment Label Distribution")
axes[0, 0].set_ylabel("Count")

# Avg engagement by platform
avg_engagement.plot(kind="bar", ax=axes[0, 1], color="#55A868")
axes[0, 1].set_title("Avg Engagement Score by Platform")
axes[0, 1].set_ylabel("Engagement Score")

# Avg engagement by topic
avg_by_topic.plot(kind="bar", ax=axes[1, 0], color="#C44E52")
axes[1, 0].set_title("Avg Engagement Score by Topic Category")
axes[1, 0].set_ylabel("Engagement Score")
axes[1, 0].tick_params(axis="x", rotation=45)

# Engagement by hour of day
df.groupby("posted_hour")["engagement_score"].mean().plot(kind="line", marker="o", ax=axes[1, 1], color="#8172B2")
axes[1, 1].set_title("Avg Engagement Score by Hour Posted")
axes[1, 1].set_xlabel("Hour of Day")
axes[1, 1].set_ylabel("Engagement Score")

plt.tight_layout()
plt.savefig("outputs/eda_overview.png", dpi=150)
print("\nSaved EDA charts to outputs/eda_overview.png")

# ---------------------------------------------------------
# 7. EXPORT CLEANED DATA (for SQL + Power BI phase)
# ---------------------------------------------------------
df.to_csv("outputs/cleaned_social_media_data.csv", index=False)
print("\nSaved cleaned dataset to outputs/cleaned_social_media_data.csv")
print("Final shape:", df.shape)
